class AppConst{
    static apiEndPoint = "https://testapi.teamralli.com/v1";
    static projectId= "saheli";
    static apiSecretKey="6f9ae8eccd3af3342b234b3e9967f8d22496b6b45fca81ebc7d75fe0a50db080bc883c26500c57f0deebca35111fca6091ff1f0aeb3c9cca0a0a039624008be755f6d21edc7869f69ef1cd0718f2c4540af1d975b4ca8c86a5f5ef692c748db23c90835a73d37cac501e7238533be1e0dc39b9b4b56a7f9cc7e6a273e6a6a0db";
}


export default AppConst;